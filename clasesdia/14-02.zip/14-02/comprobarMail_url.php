<!DOCTYPE html>
<html lang="es">
    <head>
        <meta chaset="utf-8">
        <meta name="keywords" content="pruebas">
        <meta name="description" content=" prueba pagina web">
        <meta name="author" content="LJR">
        <title>  </title>
        <link rel="stylesheet" href="estiloFormulario.css">
    </head>
             <body>

             <form action="http://bytecluster.com/recibe.php" method="GET">
                    <p> Tu mail </p>
                    <input type="email" name="correo1">
                    <input type="submit" value="ENVIAR"> 
                 </form>
                 <form action="http://bytecluster.com/recibe.php" method="GET">
                    <p> Url </p>
                    <input type="url" name="url">
                    <input type="submit" value="ENVIAR"> 
                 </form>
               
                
             </body>



 </html>