<?php
$sorteo=rand(1,10);
if($sorteo==6){
    echo "paella gratis";   
} elseif($sorteo==10){
    echo "paella gratis"; 

}

else{
   echo " no paella";
}






















?>