<!DOCTYPE html>
<html lang="es">
    <head>
        <meta chaset="utf-8">
        <title>  </title>
        <meta name="keywords" content="pruebas">
        <meta name="description" content=" prueba pagina web">
        <meta name="author" content="LJR">
         

   
    </head>
             <body>
                <?php
                $columnas=["nombre","stock","vendidos"];
                $coches=[
                                ["VOLVO",22,18],
                                ["BMW",15,13],
                                ["Saab",5,2],
                                ["Land Rover",17,15]
                        ];
                        foreach ($columnas as $coches){

                               echo $columnasS

                        }

                
                  
                  
              
               

                
                
                
                
              
                ?>
                

                  
             </body>
