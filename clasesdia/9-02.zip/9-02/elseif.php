<!DOCTYPE html>
<html lang="es">
    <head>
        <meta chaset="utf-8">
        <title>  </title>
        <meta name="keywords" content="pruebas">
        <meta name="description" content=" prueba pagina web">
        <meta name="author" content="LJR">
    </head>
             <body>
        
             <?php
                $horas=rand(01,24);
                    if($horas<06){
                                     echo "Buenos Días Luis";
    
    
                 } elseif($horas>20){
                                      echo "Buenas Noches"; 

                 }
                   else{
                                      echo "No puedo Dormir";
                 }

?>








                
             </body>



</html>


































