<!DOCTYPE html>
<html lang="es">
    <head>
        <meta chaset="utf-8">
        <title>  </title>
        <meta name="keywords" content="pruebas">
        <meta name="description" content=" prueba pagina web">
        <meta name="author" content="LJR">
    </head>
             <body>
                <?php
        
              echo  (rand(1,10)==5)?"Paella gratis": "no hay paella";








              ?>
                
             </body>



</html>