!DOCTYPE html>
<html lang="es">
    <head>
        <meta chaset="utf-8">
        <title>  </title>
        <meta name="keywords" content="pruebas">
        <meta name="description" content=" prueba pagina web">
        <meta name="author" content="LJR">
    </head>
             <body>
               <?php

               $alimentos=["Alimento","kilos","euros"]
               $lista [
                   [ "tomates", 3 , 7],
                   [ "cebollas", 2 , 20],
                   [ "pepinos", 1, 15],
                   [ "naranjas", 3 , 30],
                   [ "mandarinas", 1 , 18],
                   [ "agucate", 4 , 14]

                 
               ];










               




                 

             
               ?>
              









                
             </body>



</html>