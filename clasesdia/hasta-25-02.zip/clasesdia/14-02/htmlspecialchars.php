<!DOCTYPE html>
<html lang="es">
    <head>
        <meta chaset="utf-8">
        <meta name="keywords" content="pruebas">
        <meta name="description" content=" prueba pagina web">
        <meta name="author" content="LJR">
        <title>  </title>
        <link rel="stylesheet" href="estiloFormulario.css">
    </head>
             <body>

              <a> l<<<:==999 hola </a>
              <?php  
              
              
              echo htmlspecialchars ("l<<<>>>>:==999 hola ");





              ?>

              
               
                
             </body>



 </html>