<!DOCTYPE html>
<html lang="es">
    <head>
        <meta chaset="utf-8">
        <title>  </title>
        <meta name="keywords" content="pruebas">
        <meta name="description" content=" prueba pagina web">
        <meta name="author" content="LJR">
        <link rel="stylesheet" href="estilosLibreria.css">
    </head>
             <body>
                 <h1> "Libreria"</h1>
              <?php
               echo '<div class="fuera">';
              include("elcomparador.php");
              include("estilosElcomparador.css");
              include("array-ejercicio6.php");
         

              
              echo "</div>";


              








            ?> 
             
             </body>



</html>