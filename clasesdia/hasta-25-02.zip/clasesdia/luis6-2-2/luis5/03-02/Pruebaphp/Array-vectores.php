<!DOCTYPE html>
<html lang="es">
    <head>
        <meta chaset="utf-8">
        <title>  </title>
        <meta name="keywords" content="pruebas">
        <meta name="description" content=" prueba pagina web">
        <meta name="author" content="LJR">
    </head>
             <body>
                <?php

                  $coches=[ "volvo","BMW","Toyota"

];
                  print_r($coches);
                                                      
                 
                 ?>
                

                       

                 
                 
                
             </body>
